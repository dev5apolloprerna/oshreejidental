<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Branch extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('branch_model');
    }

    /* List all announcements */
    public function index()
    {
        if (staff_cant('view', 'branch')) {
            access_denied('branch');
        }
        if ($this->input->is_ajax_request()) {
            $this->app->get_table_data(module_views_path('branch', 'table'));
        }
        // $this->app_scripts->add('circle-progress-js','assets/plugins/jquery-circle-progress/circle-progress.min.js');
        $data['title']                 = _l('branch_tracking');
        $this->load->view('manage', $data);
    }
    public function add($id = '')
    {
        if (staff_cant('view', 'branch')) {
            access_denied('branch');
        }
        if ($this->input->post()) {
            if ($id == '') {
                if (staff_cant('create', 'branch')) {
                    access_denied('branch');
                }
                $data['image']=$_FILES['image']['name'];
                $id = $this->branch_model->add($this->input->post());
                $image=$this->profile_images($id);
                $CI = & get_instance();
                hooks()->do_action('before_remove_branch_icon_image');
                $CI->db->where('branchid', $id);
                $CI->db->update(db_prefix() . 'branch', ['image' => $image]);
                if ($id) {
                    set_alert('success', _l('added_successfully', _l('branch')));
                    redirect(admin_url('branch/branch/' . $id));
                }
            } else {
                if (staff_cant('edit', 'branch')) {
                    access_denied('branch');
                }
                $success = $this->branch_model->update($this->input->post(), $id);
                $image=$this->profile_images($id);
                $CI = & get_instance();
                hooks()->do_action('before_remove_branch_icon_image');
                $CI->db->where('branchid', $id);
                $CI->db->update(db_prefix() . 'branch', ['image' => $image]);
                if ($success) {
                    set_alert('success', _l('updated_successfully', _l('branch')));
                }
                redirect(admin_url('branch/branch/' . $id));
            }
        }
        if ($id == '') {
            $title = _l('add_new', _l('branch_lowercase'));
        } else {
            $data['branch']        = $this->branch_model->get($id);
           

            $title = _l('edit', _l('branch_lowercase'));
        }

        $this->load->model('staff_model');
        $data['members'] = $this->branch_model->get();

        $this->load->model('contracts_model');
        $data['contract_types']        = $this->contracts_model->get_contract_types();
        $data['title']                 = $title;
        // $this->app_scripts->add('circle-progress-js','assets/plugins/jquery-circle-progress/circle-progress.min.js');
        $this->load->view('branch', $data);
    }

    public function branch($id = '')
    {
        if (staff_cant('view', 'branch')) {
            access_denied('branch');
        }
        if ($this->input->post()) {
            if ($id == '') {
                if (staff_cant('create', 'branch')) {
                    access_denied('branch');
                }
                $id = $this->branch_model->add($this->input->post());
                if ($id) {
                    set_alert('success', _l('added_successfully', _l('branch')));
                    redirect(admin_url('branch/branch/' . $id));
                }
            } else {
                if (staff_cant('edit', 'branch')) {
                    access_denied('branch');
                }
                $success = $this->branch_model->update($this->input->post(), $id);
                if ($success) {
                    set_alert('success', _l('updated_successfully', _l('branch')));
                }
                redirect(admin_url('branch/branch/' . $id));
            }
        }
        if ($id == '') {
            $title = _l('add_new', _l('branch_lowercase'));
        } else {
            $data['branch']        = $this->branch_model->get($id);
           

            $title = _l('edit', _l('branch_lowercase'));
        }

        $this->load->model('staff_model');
        $data['members'] = $this->branch_model->get();

        $this->load->model('contracts_model');
        $data['contract_types']        = $this->contracts_model->get_contract_types();
        $data['title']                 = $title;
        // $this->app_scripts->add('circle-progress-js','assets/plugins/jquery-circle-progress/circle-progress.min.js');
        $this->load->view('branch', $data);
    }

    /* Delete announcement from database */
    public function delete($id)
    {
        if (staff_cant('delete', 'branch')) {
            access_denied('branch');
        }
        if (!$id) {
            redirect(admin_url('branch'));
        }
        $response = $this->branch_model->delete($id);
        if ($response == true) {
            set_alert('success', _l('deleted', _l('branch')));
        } else {
            set_alert('warning', _l('problem_deleting', _l('branch_lowercase')));
        }
        redirect(admin_url('branch'));
    }

    public function notify($id, $notify_type)
    {
        if (staff_cant('edit', 'branch') && staff_cant('create', 'branch')) {
            access_denied('branch');
        }
        if (!$id) {
            redirect(admin_url('branch'));
        }
        $success = $this->branch_model->notify_staff_members($id, $notify_type);
        if ($success) {
            set_alert('success', _l('branch_notify_staff_notified_manually_success'));
        } else {
            set_alert('warning', _l('branch_notify_staff_notified_manually_fail'));
        }
        redirect(admin_url('branch/branch/' . $id));
    }

    public function profile_images($id='') 
    {
    
       $data['image'] =$this->input->post($_FILES['image']);
       
        if (isset($_FILES['image']['name']) && $_FILES['image']['name'] != '') 
        {
            hooks()->do_action('before_upload_client_image');
            $path = $this->get_upload_path_by_type('branch') . $id.'/';
            $tmpFilePath = $_FILES['image']['tmp_name'];
           
            
            if (!empty($tmpFilePath) && $tmpFilePath != '') {
                    // Getting file extension
                    $extension= strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
                    $allowed_extensions = [
                        'jpg',
                        'jpeg',
                        'png',
                    ];
                    $allowed_extensions = hooks()->apply_filters('client_image_upload_allowed_extensions', $allowed_extensions);
                    if (!in_array($extension, $allowed_extensions)) {
                        set_alert('warning', _l('Please Select jpg, jpeg and png formate'));
                        return false;
                    }
                    
                    $this->_maybe_create_upload_path($path);
                    $filename = uniqid() . '.' . $extension;
                    //echo $filename;exit;
                    $newFilePath = $path . '/' . $filename;
                    //echo $newFilePath;exit;
                    
                    if (move_uploaded_file($tmpFilePath, $newFilePath)) {
                        $CI                       = & get_instance();
                        $config                   = [];
                        $config['image_library']  = 'gd2';
                        $config['source_image']   = $newFilePath;
                        $config['new_image']      = 'IMG_' . $filename;
                        $config['maintain_ratio'] = true;
                        $config['width']          = hooks()->apply_filters('client_icon_image_img_width', 320);
                        $config['height']         = hooks()->apply_filters('client_icon_image_img_height', 320);
                        $CI->image_lib->initialize($config);
                        $CI->image_lib->resize();
                        $CI->image_lib->clear();
                        // Remove original image
                        unlink($newFilePath);
                    }
                } 

                return $filename;    
        }
    }
}
