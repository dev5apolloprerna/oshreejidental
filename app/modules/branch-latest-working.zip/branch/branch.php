<?php

defined('BASEPATH') or exit('No direct script access allowed');

/*
Module Name: Branch
Description: Default module for defining branch
Version: 2.3.0
Requires at least: 2.3.*
*/

define('BRANCH_MODULE_NAME', 'branch');

hooks()->add_action('after_cron_run', 'branch_notification');
hooks()->add_action('admin_init', 'branch_module_init_menu_items');
hooks()->add_action('staff_member_deleted', 'branch_staff_member_deleted');
hooks()->add_action('admin_init', 'branch_permissions');

hooks()->add_filter('migration_tables_to_replace_old_links', 'branch_migration_tables_to_replace_old_links');
hooks()->add_filter('global_search_result_query', 'branch_global_search_result_query', 10, 3);
hooks()->add_filter('global_search_result_output', 'branch_global_search_result_output', 10, 2);
hooks()->add_filter('get_dashboard_widgets', 'branch_add_dashboard_widget');

function branch_add_dashboard_widget($widgets)
{
    $widgets[] = [
        'path'      => 'branch/widget',
        'container' => 'right-4',
    ];

    return $widgets;
}

function branch_staff_member_deleted($data)
{
    $CI = &get_instance();
    $CI->db->where('staff_id', $data['id']);
    $CI->db->update(db_prefix() . 'branch', [
        'staff_id' => $data['transfer_data_to'],
    ]);
}

function branch_global_search_result_output($output, $data)
{
    if ($data['type'] == 'branch') {
        $output = '<a href="' . admin_url('branch/branch/' . $data['result']['id']) . '">' . $data['result']['subject'] . '</a>';
    }

    return $output;
}

function branch_global_search_result_query($result, $q, $limit)
{
    $CI = &get_instance();
    if (staff_can('view',  'branch')) {
        // Branch
        $CI->db->select()->from(db_prefix() . 'branch')->like('description', $q)->or_like('subject', $q)->limit($limit);

        $CI->db->order_by('subject', 'ASC');

        $result[] = [
            'result'         => $CI->db->get()->result_array(),
            'type'           => 'branch',
            'search_heading' => _l('branch'),
        ];
    }

    return $result;
}

function branch_migration_tables_to_replace_old_links($tables)
{
    $tables[] = [
        'table' => db_prefix() . 'branch',
        'field' => 'description',
    ];

    return $tables;
}

function branch_permissions()
{
    $capabilities = [];

    $capabilities['capabilities'] = [
        'view'   => _l('permission_view') . '(' . _l('permission_global') . ')',
        'create' => _l('permission_create'),
        'edit'   => _l('permission_edit'),
        'delete' => _l('permission_delete'),
    ];

    register_staff_capabilities('branch', $capabilities, _l('branch'));
}

function branch_notification()
{
    $CI = &get_instance();
    $CI->load->model('branch/branch_model');
    $branch = $CI->branch_model->get('', true);
    foreach ($branch as $branch) {
        $achievement = $CI->branch_model->calculate_branch_achievement($branch['id']);

        if ($achievement['percent'] >= 100) {
            if (date('Y-m-d') >= $branch['end_date']) {
                if ($branch['notify_when_achieve'] == 1) {
                    $CI->branch_model->notify_staff_members($branch['id'], 'success', $achievement);
                } else {
                    $CI->branch_model->mark_as_notified($branch['id']);
                }
            }
        } else {
            // not yet achieved, check for end date
            if (date('Y-m-d') > $branch['end_date']) {
                if ($branch['notify_when_fail'] == 1) {
                    $CI->branch_model->notify_staff_members($branch['id'], 'failed', $achievement);
                } else {
                    $CI->branch_model->mark_as_notified($branch['id']);
                }
            }
        }
    }
}

/**
* Register activation module hook
*/
register_activation_hook(BRANCH_MODULE_NAME, 'branch_module_activation_hook');

function branch_module_activation_hook()
{
    $CI = &get_instance();
    require_once(__DIR__ . '/install.php');
}

/**
* Register language files, must be registered if the module is using languages
*/
register_language_files(BRANCH_MODULE_NAME, [BRANCH_MODULE_NAME]);

/**
* Init branch module menu items in setup in admin_init hook
* @return null
*/
function branch_module_init_menu_items()
{
    $CI = &get_instance();

    $CI->app->add_quick_actions_link([
        'name'       => _l('branch'),
        'url'        => 'branch/branch',
        'permission' => 'branch',
        'position'   => 56,
        'icon'       => 'fa-solid fa-bars-progress',
    ]);

    if (staff_can('view',  'branch')) {
        $CI->app_menu->add_sidebar_children_item('utilities', [
            'slug'     => 'branch-tracking',
            'name'     => _l('branch'),
            'href'     => admin_url('branch'),
            'position' => 24,
        ]);
    }
}


/**
* Get branch types for the branch feature
*
* @return array
*/
function get_branch_types()
{
    $types = [
        [
            'key'       => 1,
            'lang_key'  => 'branch_type_total_income',
            'subtext'   => 'branch_type_income_subtext',
            'dashboard' => has_permission('invoices', 'view'),
        ],
        [
            'key'       => 8,
            'lang_key'  => 'branch_type_invoiced_amount',
            'subtext'   => '',
            'dashboard' => has_permission('invoices', 'view'),
        ],
        [
            'key'       => 2,
            'lang_key'  => 'branch_type_convert_leads',
            'dashboard' => is_staff_member(),
        ],
        [
            'key'       => 3,
            'lang_key'  => 'branch_type_increase_customers_without_leads_conversions',
            'subtext'   => 'branch_type_increase_customers_without_leads_conversions_subtext',
            'dashboard' => has_permission('customers', 'view'),
        ],
        [
            'key'       => 4,
            'lang_key'  => 'branch_type_increase_customers_with_leads_conversions',
            'subtext'   => 'branch_type_increase_customers_with_leads_conversions_subtext',
            'dashboard' => has_permission('customers', 'view'),

        ],
        [
            'key'       => 5,
            'lang_key'  => 'branch_type_make_contracts_by_type_calc_database',
            'subtext'   => 'branch_type_make_contracts_by_type_calc_database_subtext',
            'dashboard' => has_permission('contracts', 'view'),
        ],
        [
            'key'       => 7,
            'lang_key'  => 'branch_type_make_contracts_by_type_calc_date',
            'subtext'   => 'branch_type_make_contracts_by_type_calc_date_subtext',
            'dashboard' => has_permission('contracts', 'view'),
        ],
        [
            'key'       => 6,
            'lang_key'  => 'branch_type_total_estimates_converted',
            'subtext'   => 'branch_type_total_estimates_converted_subtext',
            'dashboard' => has_permission('estimates', 'view'),
        ],
    ];

    return hooks()->apply_filters('get_branch_types', $types);
}

/**
* Get branch type by given key
*
* @param  int $key
*
* @return array
*/
function get_branch_type($key)
{
    foreach (get_branch_types() as $type) {
        if ($type['key'] == $key) {
            return $type;
        }
    }
}

/**
* Translate branch type based on passed key
*
* @param  mixed $key
*
* @return string
*/
function format_branch_type($key)
{
    foreach (get_branch_types() as $type) {
        if ($type['key'] == $key) {
            return _l($type['lang_key']);
        }
    }

    return $type;
}

function branch_icon_image_url($id, $type = 'IMG')
{
    $url  = base_url('assets/images/user-placeholder.jpg');
    $CI   = &get_instance();
    $path = $CI->app_object_cache->get('branch-profile-image-path-' . $id);

    if (!$path) {
        $CI->app_object_cache->add('branch-profile-image-path-' . $id, $url);

        $CI->db->select('image');
        $CI->db->from(db_prefix() . 'branch');
        $CI->db->where('branchid', $id);
        $branch = $CI->db->get()->row();

        if ($branch && !empty($branch->image)) {
            $path = 'uploads/branch_images/' . $id . '/' . $type . '_' . $branch->image;
            $CI->app_object_cache->set('branch-profile-image-path-' . $id, $path);
        }
    }

    if ($path && file_exists($path)) {
        $url = base_url($path);
    }

    return $url;
}